#include <iostream>

using namespace std;

int main()
{
    int matrix[10][10], i, j, rows, columns;

    cout<<"Enter number of rows:";
    cin>>rows;

    cout<<"Enter number of columns:";
    cin>>columns;

    cout<<"Enter "<<rows * columns<<" Integers:";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cin>>matrix[i][j];
        }
    }

    cout<<"Matrix is:"<<endl;
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            cout<<matrix[i][j]<<"\t";
        }
        cout<<endl;
    }

    cout<<"Principal Diagonal is:\n";
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
                if(i == j)
                    cout<<matrix[i][j]<<"\t";
        }
    }

    return 0;
}
