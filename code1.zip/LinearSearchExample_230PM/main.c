#include <stdio.h>
#include <stdlib.h>

int main()
{
    int list[20], i, n, search;

    printf("Enter any number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &list[i]);
    }

    printf("Elements in the list are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", list[i]);
    }

    printf("\n");

    printf("Enter any number that you want to search:");
    scanf("%d", &search);

    for(i=0; i<n; i++)
    {
        if(list[i] == search)
        {
            printf("%d element is found at location %d.", search, i+1);
            break;
        }
    }

    if(i == n)
        printf("%d element is not found in the list.", search);

    return 0;
}
