#include <iostream>

using namespace std;

int main()
{
    int list[20], i, n, search;

    cout<<"Enter any number of elements:";
    cin>>n;

    cout<<"Enter "<<n<<" Integers:";
    for(i=0; i<n; i++)
    {
        cin>>list[i];
    }

    cout<<"Elements in the list are:\n";
    for(i=0; i<n; i++)
    {
        cout<<list[i]<<" ";
    }

    cout<<endl;

    cout<<"Enter any number that you want to search:";
    cin>>search;

    for(i=0; i<n; i++)
    {
        if(list[i] == search)
        {
            cout<<search<<" element is found at location "<<i+1<<".";
            break;
        }
    }

    if(i == n)
        cout<<search<<" element is found in the list.";

    return 0;
}
