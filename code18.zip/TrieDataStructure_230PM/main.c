#include <stdio.h>
#include <stdlib.h>
#define N 26

struct TrieNode
{
    char data;
    struct TrieNode *children[N];
    int isleaf;
};

struct TrieNode *createTrieNode(char data)
{
    struct TrieNode *n;

    n = (struct TrieNode *)malloc(sizeof(struct TrieNode));

    for(int i=0; i<N; i++)
    {
        n->children[i] = NULL;
    }

    n->isleaf = 0;
    n->data = data;

    return(n);
};

struct TrieNode *insertTrie(struct TrieNode *root, char *word)
{
    struct TrieNode *temp = root;

    for(int i = 0; word[i]!='\0'; i++)
    {
        int index = (int) word[i] - 'a';

        if(temp->children[index] == NULL)
        {
            temp->children[index] = createTrieNode(word[i]);
        }
        temp = temp->children[index];
    }
    temp->isleaf = 1;
    return(root);
};

int searchTrie(struct TrieNode *root, char *word)
{
    struct TrieNode *temp = root;

    for(int i=0; word[i] != '\0'; i++)
    {
        int position = word[i] - 'a';

        if(temp->children[position] == NULL)
        {
            return 0;
        }

        temp = temp->children[position];
    }
    if(temp != NULL && temp->isleaf == 1)
        return 1;

    return 0;
}

void deleteTrieNode(struct TrieNode *n)
{
    for(int i=0; i<N; i++)
    {
        if(n->children[i] != NULL)
        {
            deleteTrieNode(n->children[i]);
        }

        else
        {
            continue;
        }
    }
    free(n);
}

void displayTrie(struct TrieNode *root)
{
    if(!root)
    {
        return;
    }
    struct TrieNode *temp = root;
    printf("%c  ", temp->data);

    for(int i=0; i<N; i++)
    {
        displayTrie(temp->children[i]);
    }
}

void printSearch(struct TrieNode *root, char *word)
{
    printf("Searching for %s:", word);
    if(searchTrie(root, word) == 0)
        printf("Not Found.\n");
    else
        printf("Found.\n");
}

int main()
{
    struct TrieNode *root;

    root = createTrieNode('\0');

    root = insertTrie(root, "hello");
    root = insertTrie(root, "hi");

    printSearch(root, "hi");
    printSearch(root, "hello");
    printSearch(root, "he");

    displayTrie(root);

    deleteTrieNode(root);

    return 0;
}
