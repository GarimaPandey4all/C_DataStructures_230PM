#include <stdio.h>
#include <stdlib.h>

//Defining a node (Data type)
struct node
{
    int info;
    struct node *link;
};

struct node *last = NULL;

//Create a node
struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};

//insert to Empty list
int insertToEmpty()
{
    struct node *temp;

    if(last == NULL)
    {
    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    last = temp;
    last->link = last;
    return(1);
    }
    else
    {
        printf("List is not Empty.");
        return(0);
    }
}

//insert at start in a list
int insertAtStart()
{
    struct node *temp;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    else
    {
    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = last->link;

    last->link = temp;
    return(1);
    }
}

//insert at end in a list
int insertAtEnd()
{
    struct node *temp;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    else
    {
    temp = createNode();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = last->link;

    last->link = temp;

    last = temp;
    return(1);
    }
}

//insert after a particular node in a list
int insertAfterNode()
{
    struct node *temp, *ptr;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    printf("Enter any value to be search:");
    scanf("%d", &search);

    ptr = last->link;

    do
    {
    if(ptr->info == search)
    {
        temp = createNode();

        printf("Enter a number:");
        scanf("%d", &temp->info);

        temp->link = ptr->link;
        ptr->link = temp;

        if(ptr == last)
            last = temp;

        return(1);
    }
    ptr = ptr->link;
    }while(ptr != last->link);

    printf("%d is not found in a list.", search);
    return(0);
}

//Delete from a list
int deleteNode()
{
    struct node *p, *t;
    int search;

    if(last == NULL)
    {
        printf("List is Empty.");
        return(0);
    }

    printf("Enter any value to be search:");
    scanf("%d", &search);

    //If only one node exist in a list
    if(last == last->link && last->info == search)
    {
        t = last;
        last = NULL;
        free(t);
        return(1);
    }

    //If only two nodes exist in a list
    if(last->link->info == search)
    {
        t = last->link;
        last->link = t->link;
        free(t);
        return(1);
    }

    //If we have more than two nodes in a list

    p = last->link;

    while(p->link != last)
    {
        if(p->link->info == search)
        {
            t = p->link;
            p->link = t->link;
            free(t);
            return(1);
        }
        p = p->link;
    }

    /*If we have more than two nodes in a list but we want to
    delete last node of a list*/

    if(last->info == search)
    {
        t = last;
        p->link = last->link;
        last = p;
        free(t);
        return(1);
    }

    //If searched node is not found in a list
    printf("%d is not found in a list.", search);
    return(0);
}

//Traversing a list
void viewList()
{
    struct node *T;

    if(last == NULL)
        printf("List is Empty.");

    else
    {
        T = last->link;
        do
        {
            printf("%d ", T->info);
            T = T->link;
        }while(T != last->link);
    }
}

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Add value to Empty list.");
        printf("\n2. Add value at beginning in a list.");
        printf("\n3. Add value at end in a list.");
        printf("\n4. Add value after a particular node in a list.");
        printf("\n5. Delete any node from a list.");
        printf("\n6. View List.");
        printf("\n7. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertToEmpty();
            break;

        case 2:
            insertAtStart();
            break;

        case 3:
            insertAtEnd();
            break;

        case 4:
            insertAfterNode();
            break;

        case 5:
            deleteNode();
            break;

        case 6:
            viewList();
            break;

        case 7:
            exit(0);

        default:
            printf("Invalid Case.");
        }
    }

    return 0;
}
