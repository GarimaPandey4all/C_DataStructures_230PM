#include <stdio.h>
#include <stdlib.h>

int main()
{
    int heap[20], n, i, j, root, c, temp;

    printf("Enter number of Elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n",  n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &heap[i]);
    }

    printf("Unsorted List is:\n");
    for(i=0; i<n; i++)
    {
        printf("%d", heap[i]);
    }

    //Logic for Heap Sort

    for(i=0; i<n; i++)
    {
        c = i;

        do
        {
            root = (c-1)/2;

            if(heap[root] < heap[c]) //Create Max Heap
            {
                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }
            c = root;
        }while(c != 0);
    }

    printf("Max Heap is:\n");
    for(i=0; i<n; i++)
        printf("%d ", heap[i]);

    for(j= n-1; j>=0; j--) //swap max element with leaf element of the tree
    {
        temp = heap[0];
        heap[0] = heap[j];
        heap[j] = temp;
        root = 0;

        do
        {
            c = 2*root+1; //left node of root element

            if((heap[c] < heap[c+1]) && c<j)
            {
                //Again Rearrange the Max heap

                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }
            root = c;
        }while(c<j);
    }

    printf("Sorted List is:\n");
    for(i=0; i<n; i++)
        printf("%d ", heap[i]);

    return 0;
}
