#include <stdio.h>
#include <stdlib.h>

//Defining a node (Data Type)

struct node
{
    int info;
    struct node *link;
};

struct node *START = NULL;

struct node *createNote()
{
    struct node *n;

    n = (struct node *)malloc(sizeof(struct node));

    return(n);
};


//Insertion in a list at the end
void insertNode()
{
    struct node *temp, *temp1;

    temp = createNote();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = NULL;

    if(START == NULL)
        START = temp;
    else
    {
        temp1 = START;
        while(temp1->link != NULL)
        {
            temp1 = temp1->link;
        }
        temp1->link = temp;
    }

}

//Delete First Node from a list

void deleteFirstNode()
{
    struct node *t;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        t = START;
        START = START->link;
        free(t);
    }
}

void viewList()
{
    struct node *T;

    if(START == NULL)
        printf("List is Empty.");
    else
    {
        T = START;
        while(T->link != NULL)
        {
            printf("%d ", T->info);
            T = T->link;
        }
    }
}


int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Add value in a list at the end.");
        printf("\n2. Delete first node from a list.");
        printf("\n3. View List.");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            insertNode();
            break;

        case 2:
            deleteFirstNode();
            break;

        case 3:
            viewList();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Case.");
        }
    }


    return 0;
}
