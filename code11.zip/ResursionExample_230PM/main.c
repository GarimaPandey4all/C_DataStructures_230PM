#include <stdio.h>
#include <stdlib.h>

int sum(int a)
{
    int x;

    if(a == 1)//base case
    return(a);

    x = a + sum(a-1);
    return(x);
}


int main()
{
    int y;

    y = sum(4);

    printf("Sum of natural numbers is:%d", y);

    return 0;
}
