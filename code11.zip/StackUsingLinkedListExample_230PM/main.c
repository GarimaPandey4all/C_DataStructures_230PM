#include <stdio.h>
#include <stdlib.h>

//Defining a Stack (Data Type)
struct stack
{
    int info;
    struct stack *link;
};

struct stack *Top = NULL;

//Create a stack
struct stack *createStack()
{
    struct stack *n;

    n = (struct stack *)malloc(sizeof(struct stack));

    return(n);
};

//Insert(push()) in a stack
void push()
{
    struct stack *temp;

    temp = createStack();

    printf("Enter a number:");
    scanf("%d", &temp->info);

    temp->link = Top;

    Top = temp;
}

//Delete(pop()) from a stack
int pop()
{
    struct stack *temp;

    if(Top == NULL)
    {
        printf("Stack is Empty. Underflow.");
        return(0);
    }
    else
    {
        temp = Top;

        Top = Top->link;

        free(temp);

        return(1);
    }
}

//Traverse/Display Stack
int display()
{
    struct stack *T;

    if(Top == NULL)
    {
        printf("Stack is Empty. UnderFlow.");
        return(0);
    }
    else
    {
        T = Top;

        while(T != NULL)
        {
            printf("%d ", T->info);
            T = T->link;
        }
        return(1);
    }
}


int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Insert in a stack.");
        printf("\n2. Delete from a stack.");
        printf("\n3. Display stack.");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            push();
            break;

        case 2:
            pop();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }
}
