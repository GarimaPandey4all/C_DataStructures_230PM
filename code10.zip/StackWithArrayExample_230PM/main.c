#include <stdio.h>
#include <stdlib.h>
#define MAX 100

void push();
void pop();
void display();

int top = -1; //stack is empty.
int i, stack[MAX];

int main()
{
    int choice;

    while(1)
    {
        printf("\n\n1. Push in a Stack.");
        printf("\n2. Pop from a Stack.");
        printf("\n3. Display values of a Stack.");
        printf("\n4. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            push();
            break;

        case 2:
            pop();
            break;

        case 3:
            display();
            break;

        case 4:
            exit(0);

        default:
            printf("Invalid Case.");

        }
    }
    return 0;
}

//insert in a stack
void push()
{
    int value;

    if(top == MAX-1)
        printf("Stack Overflow.");
    else
    {
        printf("Enter the value to be inserted:");
        scanf("%d", &value);

        top++;
        stack[top] = value;
    }
}

//delete from a stack
void pop()
{
     int value;

     if(top == -1)
        printf("Stack Underflow.");
    else
    {
        value = stack[top];
        printf("The deleted value is %d.", value);
        top--;
    }
}

//Display the values of a stack
void display()
{
    if(top == -1)
        printf("Stack Underflow.");

    if(top >= 0)
    {
        printf("Values in Stack are:\n");
        for(i = top; i>=0; i--)
        {
            printf("%d\n", stack[i]);
        }
    }
}
