#include <iostream>
#include <queue>

using namespace std;

void displayPQueue(priority_queue <int> pq)
{
    priority_queue <int> pqueue = pq;

    while(!pqueue.empty())
    {
        cout<<"\t"<<pqueue.top();
        pqueue.pop();
    }
    cout<<endl;
}


int main()
{
    priority_queue <int> pq;

    pq.push(9);
    pq.push(14);
    pq.push(8);
    pq.push(3);
    pq.push(6);

    cout<<"Size of the queue is:"<<pq.size();
    cout<<"\nTop element of the queue is:"<<pq.top();

    //Priority Queue is:
    cout<<"\nPriority queue is:";
    displayPQueue(pq);

    //Delete the top element
    pq.pop();

    cout<<"\nPriority queue, after pop up the top element:";
    displayPQueue(pq);

    return 0;
}
