#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[20], i, n, first, last, middle, search;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in a List:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    printf("Enter number that you want to search:");
    scanf("%d", &search);

    first = 0;
    last = n-1;

    middle = (first+last)/2;

    while(first<=last)
    {
        if(array[middle] < search)
        {
            first = middle + 1;
        }
        else if(array[middle] == search)
        {
            printf("%d element found in the list.", search);
            break;
        }
        else
        {
            last = middle - 1;
        }

        middle = (first+last)/2;

    }

    return 0;
}
