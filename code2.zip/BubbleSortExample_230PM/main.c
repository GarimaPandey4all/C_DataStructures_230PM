#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[20], i, j, temp, n;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in the list are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    //Bubble Sorting Logic: 5, 4, 3, 2, 1

    /*
    i=0
        5, 4, 3, 2, 1
        4, 5, 3, 2, 1
        4, 3, 5, 2, 1
        4, 3, 2, 5, 1
        4, 3, 2, 1, 5

    i=1
        4, 3, 2, 1, 5
        3, 4, 2, 1, 5
        3, 2, 4, 1, 5
        3, 2, 1, 4, 5



    */

    for(i=0; i<n-1; i++)
    {
        for(j=0; j<n-1-i; j++)
        {
            if(array[j]>array[j+1])
            {
                temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }

    printf("\nBubble Sorted List is:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    return 0;
}
