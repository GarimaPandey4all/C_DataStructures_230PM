#include <stdio.h>
#include <stdlib.h>

struct node
{
  int info;
  struct node *left;
  struct node *right;
};

struct node *createNode(int value)
{
  struct node *n = (struct node *)malloc(sizeof(struct node));

  n->info = value;

  n->left = NULL;
  n->right = NULL;

  return (n);
}

void traversePreOrder(struct node *temp)
{
  if (temp != NULL)
  {
    printf(" %d", temp->info);
    traversePreOrder(temp->left);
    traversePreOrder(temp->right);
  }
}

void traverseInOrder(struct node *temp)
{
  if (temp != NULL)
  {
    traverseInOrder(temp->left);
    printf(" %d", temp->info);
    traverseInOrder(temp->right);
  }
}

void traversePostOrder(struct node *temp)
{
  if (temp != NULL)
  {
    traversePostOrder(temp->left);
    traversePostOrder(temp->right);
    printf(" %d", temp->info);
  }
}

int main()
{
  struct node *root = createNode(1);

  root->left = createNode(2);
  root->right = createNode(3);

  root->left->left = createNode(4);

  printf("The preorder traversal of the tree is: ");
  traversePreOrder(root);
  printf("\nThe inorder traversal of the tree is: ");
  traverseInOrder(root);
  printf("\nThe postorder traversal of the tree is: ");
  traversePostOrder(root);
}
