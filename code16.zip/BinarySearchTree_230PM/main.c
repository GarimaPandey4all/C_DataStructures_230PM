#include <stdio.h>
#include <stdlib.h>

struct BSTNode
{
    int info;
    struct BSTNode *left;
    struct BSTNode *right;
};

struct BSTNode *createNode(int value)
{
    struct BSTNode *n;

    n = (struct BSTNode *)malloc(sizeof(struct BSTNode));

    n->info = value;
    n->left = NULL;
    n->right = NULL;

    return(n);
};

struct BSTNode *insertNode(struct BSTNode *root, int value)
{
    if(root == NULL)
        return createNode(value);
    if(value < root->info)
        root->left = insertNode(root->left, value);
    else if(value > root->info)
        root->right = insertNode(root->right, value);

    return(root);
};

void inorder(struct BSTNode * root)
{
    if(root != NULL)
    {
        inorder(root->left);
        printf("%d ", root->info);
        inorder(root->right);
    }
}

int main()
{
    struct BSTNode *root = NULL;

    root = insertNode(root, 8);

    insertNode(root, 3);
    insertNode(root, 1);
    insertNode(root, 6);
    insertNode(root, 7);
    insertNode(root, 10);
    insertNode(root, 14);
    insertNode(root, 4);

    inorder(root);

    return 0;
}
