#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[20], i, j, n, temp, min;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in List are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    //Logic of Selection Sort

    /*
        34 , 10, 8, 19, 7

    */

    for(i=0; i<n-1; i++)
    {
        min = i;
        for(j=i+1; j<n; j++)
        {
            if(array[j] < array[min])
                min = j; //min=4
        }

        //swapping

        temp = array[i];
        array[i] = array[min];
        array[min] = temp;
    }

    printf("Selection Sorted List is:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    return 0;
}
