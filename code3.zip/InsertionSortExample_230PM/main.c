#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[20], i, j, n, temp;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d Integers:\n", n);
    for(i=0; i<n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in List are:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    //Logic for Insertion Sort
    for(i=1; i<n; i++)
    {
        temp = array[i];
        j = i-1; // i-1 to 0

        while(j>=0 && array[j]>temp)
        {
            array[j+1] = array[j];
            j = j-1; //-1
        }
        array[j+1] = temp;
    }

    printf("Insertion Sorted List is:\n");
    for(i=0; i<n; i++)
    {
        printf("%d ", array[i]);
    }

    return 0;
}
