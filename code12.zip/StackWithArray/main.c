#include <stdio.h>
#include <stdlib.h>

//Defining a (Stack) Data Type

struct ArrayStack
{
    int top;
    int capacity;
    int *array;
};

struct ArrayStack *createStack(int cap)
{
    struct ArrayStack *stack;

    stack = (struct ArrayStack *)malloc(sizeof(struct ArrayStack));

    stack->capacity = cap;

    stack->top = -1;

    stack->array = (struct ArrayStack *)malloc(sizeof(int) * stack->capacity);

    return(stack);

};

int isFull(struct ArrayStack *stack)
{
    if(stack->top == stack->capacity-1)
    return(1);
    else
    return(0);
}

int isEmpty(struct ArrayStack *stack)
{
    if(stack->top == -1)
        return(1);
    else
        return(0);
}

void push(struct ArrayStack *stack, int value)
{
    if(!isFull(stack))
    {
        stack->top++;

        stack->array[stack->top] = value;
    }
}

int pop(struct ArrayStack *stack)
{
    int value;

    if(!isEmpty(stack))
    {
        value = stack->array[stack->top];
        stack->top--;
        return(1);
    }
    return(-1);
}

int main()
{
    int choice, value;

    struct ArrayStack *stack;

    stack = createStack(5);

    while(1)
    {
        printf("\n\n1. Push.");
        printf("\n2. Pop.");
        printf("\n3. Exit.");
        printf("\n\nEnter your choice:");
        scanf("%d", &choice);

        switch(choice)
        {
        case 1:
            printf("Enter a number:");
            scanf("%d", &value);
            push(stack, value);
            break;

        case 2:
            value = pop(stack);
            if(value == -1)
                printf("Stack is Empty.");
            else
                printf("Deleted value is %d.", value);
            break;

        case 3:
            exit(0);

        default:
            printf("Invalid Choice.");
        }
    }
    return 0;
}
