#include <stdio.h>
#include <stdlib.h>
#define SIZE 10

//Defining a structure hash table
struct DataItem
{
    int data;
    int key;
};

struct DataItem *hashArray[SIZE];
struct DataItem *dummyItem;
struct DataItem *Item;

int hashFunction(int key)
{
    return key%SIZE; //return hashIndex
}

struct DataItem *search(int key)
{
    int hashIndex = hashFunction(key);

    while(hashArray[hashIndex] != NULL)
    {
        if(hashArray[hashIndex]->key == key)
            return hashArray[hashIndex];

        ++hashIndex;

        hashIndex = hashIndex%SIZE;
    }
    return NULL;
};

//Insert in to a Hash Table
void insert(int key, int data)
{
    struct DataItem *Item;

    Item = (struct DataItem *)malloc(sizeof(struct DataItem));

    Item->data = data;
    Item->key = key;

    int hashIndex = hashFunction(key);

    while(hashArray[hashIndex] != NULL && hashArray[hashIndex]->key != -1)
    {
        ++hashIndex;

        hashIndex %= SIZE;
    }
    hashArray[hashIndex] = Item;
}

//Delete from a Hash Table

struct DataItem *delete(struct DataItem *Item)
{
    struct DataItem *temp;
    int key;

    key = Item->key;

    int hashIndex = hashFunction(key);

    while(hashArray[hashIndex] != NULL)
    {
        if(hashArray[hashIndex]->key == key)
        {
            temp = hashArray[hashIndex];
            hashArray[hashIndex] = dummyItem; //(key, data) // key = -1, data = -1;
            return temp;
        }
        ++hashIndex;
        hashIndex %= SIZE;
    }
    return NULL;
};

//Display a Hash Table Values
void display()
{
    int i;
    for(i = 0; i<SIZE; i++)
    {
        if(hashArray[i] != NULL)
            printf("(%d, %d)", hashArray[i]->key, hashArray[i]->data);
        else
            printf(" __ ");
    }
    printf("\n");
}

int main()
{
    dummyItem = (struct DataItem *)malloc(sizeof(struct DataItem));
    dummyItem->data = -1;
    dummyItem->key = -1;

    insert(1, 20);
    insert(2, 70);
    insert(42, 80);
    insert(4, 25);
    insert(12, 44);
    insert(14, 32);

    display();

    Item = search(12);

    if(Item != NULL)
        printf("Element is found: %d.\n", Item->data);
    else
        printf("Element is not found.\n");

    delete(Item);
    Item = search(12);

    if(Item != NULL)
        printf("Element is found: %d.\n", Item->data);
    else
        printf("Element is not found.\n");

    display();

    return 0;
}
